<script src="core/assets/js/plugins/jquery.min.js"></script>
<script src="core/assets/js/plugins/perfect-scrollbar.min.js"></script>
<script src="core/assets/js/plugins/smooth-scrollbar.min.js"></script>

<script src="core/assets/js/cart.js"></script>