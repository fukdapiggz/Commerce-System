<?php
//initialize strings
$genericTitle = 'CommerceSystem Portal';
$genericAuthor = 'UnknowenGee';
$genericKeywords = $genericTitle.'; clothing; streetwear; buynow';
$genericDescription = 'Awesome site built for '.$genericTitle.', made by '.$genericAuthor.'.';
?>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<title><?php if ($globalTitle){echo $globalTitle.' | '.$genericTitle;}else{echo $genericTitle;} ?></title>

<meta name="keywords" content="<?php if ($globalKeywords){echo $globalKeywords.'; '.$genericKeywords;}else{echo $genericKeywords;} ?>" />
<meta name="description" content="<?php if ($globalDescription){echo $globalDescription;}else{echo $genericDescription;} ?>" />
<meta name="author" content="<?= $genericAuthor; ?>" />

<meta property="og:title" content="<?php if ($globalTitle){echo $globalTitle.' | '.$genericTitle;}else{echo $genericTitle;} ?>">
<meta property="og:type" content="website">
<meta property="og:url" content="#">
<meta property="og:description" content="<?php if ($globalDescription){echo $globalDescription;}else{echo $genericDescription;} ?>">

<link id="pageStyle" rel="stylesheet" type="text/css"  href="assets/css/material-dashboard.css" />

<!-- Fonts and icons -->
<link id="nucleoIcons" rel="stylesheet" type="text/css" href="assets/css/nucleo-icons.css" />
<link id="nucleoSVG" rel="stylesheet" type="text/css" href="assets/css/nucleo-svg.css" />

<!-- Third-Party Scripts -->
<script id="fontAwesome" src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
<link id="googleIcons" rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" />
<link id="googleCSS" rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />

<?php
//<meta property="og:image" content="image.png">

//<link rel="icon" href="/favicon.ico">
//<link rel="icon" href="/favicon.svg" type="image/svg+xml">
//<link rel="apple-touch-icon" href="/apple-touch-icon.png">
//<link rel="stylesheet" href="">
?>