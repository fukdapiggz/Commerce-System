<script id="bootStrap" src="assets/js/bootstrap.min.js"></script>
<script id="materialDashboard" src="assets/js/material-dashboard.min.js"></script>
<script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
</script>
<script id="popper" src="assets/js/plugins/popper.min.js"></script>
<script id="jQuery" src="assets/js/plugins/jquery.min.js"></script>
<script id="perfectScrollbar" src="assets/js/plugins/perfect-scrollbar.min.js"></script>
<script id="smoothScrollbar" src="assets/js/plugins/smooth-scrollbar.min.js"></script>