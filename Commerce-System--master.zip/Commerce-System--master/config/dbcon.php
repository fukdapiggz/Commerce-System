<?php

	$host = "localhost";
	$username = "root";
	$password = "username";
	$password = "";
	$database = "commerce-system";

	// Creating datbase connection
	$con = mysqli_connect($host, $username, $password, $database);

	// Check database connection
	if(!$con)
	{
		die("Connection Failed: ". mysqli_connect_error());
	}
	else{
		echo "Connected successfully!";
	}
	
?>