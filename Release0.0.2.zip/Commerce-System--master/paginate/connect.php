<?php
	$conn = new mysqli("localhost", "root", "", "commerce-system");
	if(!$conn){
		die("Fatal Error: Connection Failed!");
	}
?>