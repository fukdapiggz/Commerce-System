<?php
include('globalConfiguration.php');
//initialize strings
$genericTitle = 'CommerceSystem';
$genericAuthor = 'UnknowenGee';
$genericKeywords = $genericTitle.'; clothing; streetwear; buynow';
$genericDescription = 'Awesome site built for '.$genericTitle.', made by '.$genericAuthor.'.';
?>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title><?php if ($globalTitle){echo $globalTitle.' | '.$genericTitle;}else{echo $genericTitle;} ?></title>

<meta name="keywords" content="<?php if ($globalKeywords){echo $globalKeywords.'; '.$genericKeywords;}else{echo $genericKeywords;} ?>" />
<meta name="description" content="<?php if ($globalDescription){echo $globalDescription;}else{echo $genericDescription;} ?>" />
<meta name="author" content="<?= $genericAuthor; ?>" />

<meta property="og:title" content="<?php if ($globalTitle){echo $globalTitle.' | '.$genericTitle;}else{echo $genericTitle;} ?>">
<meta property="og:type" content="website">
<meta property="og:url" content="#">
<meta property="og:description" content="<?php if ($globalDescription){echo $globalDescription;}else{echo $genericDescription;} ?>">

<link rel="stylesheet" href="core/assets/css/stylesheet.css">
<link rel="stylesheet" href="core/assets/css/bootstrap-icons.css">
<link rel="stylesheet" href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700">

<style>
  .gradient {
    background: linear-gradient(90deg, #d53369 0%, #daae51 100%);
  }
</style>

<script src="https://cdn.tailwindcss.com"></script>

<?php include('core/assets/svg.php') ?>

<?php session_start(); ?>

<?php
//<meta property="og:image" content="image.png">

//<link rel="icon" href="/favicon.ico">
//<link rel="icon" href="/favicon.svg" type="image/svg+xml">
//<link rel="apple-touch-icon" href="/apple-touch-icon.png">
//<link rel="stylesheet" href="">
?>