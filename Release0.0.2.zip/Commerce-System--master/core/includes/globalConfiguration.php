<?php
include('config/dbcon.php');
require('core/assets/svg.php');

$get_configuration_data = "SELECT * FROM conf";
$get_configuration_data_run = mysqli_query($con, $get_configuration_data);

$configurationData = mysqli_fetch_array($get_configuration_data_run);
$confPrimaryColour = $configurationData['primaryColour']; //colourname
if ($configurationData['bouncyNav'] == 'on') { $confBouncyNav = "hover:font-semibold"; }else{ $confBouncyNav = ""; }
//Socials
if (!$configurationData['facebookLink'] == "") { $confFacebook = '<a href="https://'. $configurationData['facebookLink'] .'" target="_blank" rel="nofollow" class="text-gray-700 hover:text-gray-800 m-2  "><img src="'. $base64Facebook .'" class="w-full rounded-xl hover:shadow-lg"></a>'; }else{ $confFacebook = ""; }
if (!$configurationData['instagramLink'] == "") { $confInstagram = '<a href="https://'. $configurationData['instagramLink'] .'" target="_blank" rel="nofollow" class="text-gray-700 hover:text-gray-800 m-2  "><img src="'. $base64Instagram .'" class="w-full rounded-xl hover:shadow-lg"></a>'; }else{ $confInstagram = ""; }
if (!$configurationData['twitterLink'] == "") { $confTwitter = '<a href="http://'. $configurationData['twitterLink'] .'" target="_blank" rel="nofollow" class="text-gray-700 hover:text-gray-800 m-2  "><img src="'. $base64Twitter .'" class="w-full rounded-xl hover:shadow-lg"></a>'; }else{ $confTwitter = ""; }
?>