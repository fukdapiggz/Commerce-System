<?php
//initialize custom links
$aTitleLink = 'py-4 text-lg text-'.$confPrimaryColour.'-500 font-semibold hover:text-'.$confPrimaryColour.'-700';
$aTitleActive = 'py-4 text-lg text-'.$confPrimaryColour.'-700 font-semibold';
$aLink = 'py-4 text-grey-500 hover:text-'.$confPrimaryColour.'-700 '.$confBouncyNav;
$aActive = 'py-4 text-'.$confPrimaryColour.'-700 font-semibold';
$aCartLink = 'py-4 text-grey-500 hover:text-'.$confPrimaryColour.'-700';
$aCartActive = 'py-4 text-'.$confPrimaryColour.'-700';
$aDropdownLink = 'px-4 py-2 mt-2 text-sm text-gray-900 bg-gray-200 rounded-lg font-semibold hover:text-'.$confPrimaryColour.'-700';
$aDropdownActive = 'px-4 py-2 mt-2 text-sm bg-gray-200 rounded-lg text-'.$confPrimaryColour.'-700 font-semibold';
?>

<nav class="border-b border-gray-300">
    <div class="max-w-6xl mx-auto py-2 px-6 xl:px-0 flex items-center justify-between">

        <div class="menu-left flex items-center space-x-6">
            <a href="<?= $urlFrontpage; ?>" class="<?php if (!$activeFrontpage){echo $aTitleLink;}else{echo $aTitleActive;} ?>"><?= $genericTitle; ?></a>

            <ul class="flex items-center space-x-4">
                <li><a href="<?= $urlShop; ?>" class="<?php if (!$activeShop){echo $aLink;}else{echo $aActive;} ?>">Shop</a></li>
                <li><a href="<?= $urlCategories; ?>" class="<?php if (!$activeCategories){echo $aLink;}else{echo $aActive;} ?>">Categories</a></li>
                <li><a href="<?= $urlProducts; ?>" class="<?php if (!$activeProducts){echo $aLink;}else{echo $aActive;} ?>">Products</a></li>
                <li><a href="<?= $urlAbout; ?>" class="<?php if (!$activeAbout){echo $aLink;}else{echo $aActive;} ?>">About</a></li>
            </ul>
        </div>

        <div class="menu-right flex items-center space-x-4">
            <a href="<?= $urlCart; ?>" class="<?php if (!$activeCart){echo $aCartLink;}else{echo $aCartActive;} ?>"><table><tr><td><?= $svgCart; ?></td><td><i class="badge"><span class="total-count"></span></i></td></tr></table></a>


 
            <?php if(isset($_SESSION['auth_user'])) { ?>
            <div class="group">
                <button class="flex flex-row items-center w-full mt-2 text-base font-bold text-left uppercase bg-transparent rounded-lg md:w-auto md:inline md:mt-0 md:ml-4 focus:outline-none font-montserrat">
                    <span><?= $svgDropdown; ?> Account</span>
                </button>
                <div class="absolute z-10 hidden bg-grey-200 group-hover:block">
                    <div class="px-2 pt-2 pb-4 bg-white bg-gray-200 shadow-lg">
                        <div class="grid grid-cols-1 gap-0">
                            <span class="px-4 py-2 mt-2 text-lg text-gray-900 bg-gray-200 rounded-lg font-italic">Hello, <?= $_SESSION['auth_user']['username']; ?></p><br />
                            <a href="<?= $urlDetails; ?>" rel="nofollow" class="<?php if (!$activeDetails){echo $aDropdownLink;}else{echo $aDropdownActive;} ?>">Details</a><br /><br />
                            <a href="<?= $urlOrders; ?>" rel="nofollow" class="<?php if (!$activeOrders){echo $aDropdownLink;}else{echo $aDropdownActive;} ?>">Orders</a><br /><br />
                            <a href="<?= $urlLogout; ?>" rel="nofollow" class="<?= $aDropdownLink; ?>">Logout</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php } else { ?>
            <div class="group">
                <button class="flex flex-row items-center w-full mt-2 text-base font-bold text-left uppercase bg-transparent rounded-lg md:w-auto md:inline md:mt-0 md:ml-4 focus:outline-none font-montserrat">
                    <span><?= $svgDropdown; ?> Account</span>
                </button>
                <div class="absolute z-10 hidden bg-grey-200 group-hover:block">
                    <div class="px-2 pt-2 pb-4 bg-white bg-gray-200 shadow-lg">
                        <div class="grid grid-cols-1 gap-0">
                            <span class="px-4 py-2 mt-2 text-lg text-gray-900 bg-gray-200 rounded-lg font-italic">Hello, Guest</p><br />
                            <a href="<?= $urlRegister; ?>" class="<?php if (!$activeRegister){echo $aDropdownLink;}else{echo $aDropdownActive;} ?>">Register</a><br /><br />
                            <a href="<?= $urlLogin; ?>" class="<?php if (!$activeLogin){echo $aDropdownLink;}else{echo $aDropdownActive;} ?>">Login</a><br /><br />
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>




        </div>

    </div>
</nav>