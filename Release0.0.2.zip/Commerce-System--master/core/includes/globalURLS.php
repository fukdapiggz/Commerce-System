<?php
//Global URLs
$urlFrontpage = 'index.php';
$urlShop = 'shop.php';
$urlCategories = 'categories.php';
$urlProducts = 'products.php';
$urlAbout = 'about.php';

//Session URLs
$urlRegister = 'register.php';
$urlLogin = 'login.php';
$urlCart = 'cart.php';
$urlDetails = 'details.php';
$urlOrders = 'orders.php';
$urlLogout = 'logout.php'; //Don't count in switch function

$curURL = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);  
switch ($curURL) {
  case $urlFrontpage:
    $activeFrontpage = 1;
    //echo 'Homepage';
    break;
  case $urlShop:
    $activeShop = 1;
    //echo 'Shop';
    break;
  case $urlCategories:
    $activeCategories = 1;
    //echo 'Categories';
    break;   
  case $urlProducts:
    $activeProducts = 1;
    //echo 'Products';
    break;   
  case $urlAbout:
    $activeAbout = 1;
    //echo 'About';
    break;
  case $urlRegister:
    $activeRegister = 1;
    //echo 'Register';
    break;
  case $urlLogin:
    $activeLogin = 1;
    //echo 'Login';
    break;
  case $urlCart:
    $activeCart = 1;
    //echo 'Cart';
    break;
  case $urlDetails:
    $activeDetails = 1;
    //echo 'Details';
    break;   
  case $urlOrders:
    $activeOrders = 1;
    //echo 'Orders';
    break;   
  default:
    echo 'Error in getting location.';
}
?>