<div class="flex justify-center border-t-2">
    <?php echo $confFacebook.$confInstagram.$confTwitter; ?>
</div>