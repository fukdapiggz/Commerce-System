<?php
include 'config/dbcon.php';

//Predefine sql statement
$sql="select * from products";

//Display dynamic records
foreach ($dbo->query($sql) as $row) {
	if ($row['product_image'] == "image") { $image = "https://via.placeholder.com/240x240x.jpg"; }else{ $image = $row['product_image']; }
        echo '<!-- '. $row['product_name'] .' Start -->';
        echo '<div class="w-full md:w-1/3 xl:w-1/4 p-6">';
        echo '<a href="'. $urlProducts .'?q='. $row['product_sku'] .'"><img src="'. $image .'" class="w-full rounded-xl hover:shadow-lg"></a>';
        echo '';
        echo '<div class="pt-3 flex items-center justify-between">';
        echo '<a href="'. $urlProducts .'?q='. $row['product_sku'] .'">'. $row['product_name'] .'</a>';
        echo '';
        echo '<a class="add-to-cart text-'. $confPrimaryColour .'-500 hover:text-'. $confPrimaryColour .'-800" data-name="'. $row['product_name'] .'" data-price="'. $row['product_price'] .'">'. $svgCart .'</a>';
        echo '</div>';
        echo '';
        echo '<p class="pt-1 text-gray-400">$'. $row['product_price'] .'0 NZD</p>';
        echo '</div>';
        echo '<!-- '. $row['product_name'] .' End -->';
}
?>