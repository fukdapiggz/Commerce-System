<?php

session_start();
include('../../config/dbcon.php');

//Register user
if(isset($_POST['register_btn']))
{
	$firstName = mysqli_real_escape_string($con,$_POST['firstName']);
	$lastName = mysqli_real_escape_string($con,$_POST['lastName']);

	$inputUsername = mysqli_real_escape_string($con,$_POST['inputUsername']);

	$email = mysqli_real_escape_string($con,$_POST['email']);
	$confirmEmail = mysqli_real_escape_string($con,$_POST['confirmEmail']);

	$password = mysqli_real_escape_string($con,$_POST['password']);
	$confirmPassword = mysqli_real_escape_string($con,$_POST['confirmPassword']);

	$city = mysqli_real_escape_string($con,$_POST['city']);
	$country = mysqli_real_escape_string($con,$_POST['country']);
	$postalCode = mysqli_real_escape_string($con,$_POST['postalCode']);

	//concat items
	$name = $firstName." ".$lastName;
	$location = $city.", ".$postalCode.", ".$country;

	// Check if email not exist
	$check_email_query = "SELECT email FROM users WHERE email='$email'";
	$check_email_query_run = mysqli_query($con, $check_email_query);

	if(mysqli_num_rows($check_email_query_run) > 0)
	{
		$_SESSION['message'] = "Email already in use.";
		header('location: ../../register.php');
	}else{
		if($password == $confirmPassword)
		{
			if($email == $confirmEmail)
			{
				//Insert user data
				$insert_query = "INSERT INTO users (name,username,country,email,password) VALUES ('$name','$inputUsername','$location','$email','$password')";
				$insert_query_run = mysqli_query($con, $insert_query);

				if($insert_query_run)
				{
					$_SESSION['message'] = "Registered successfully.";
					header('location: ../../login.php');
				}else
				{
					$_SESSION['message'] = "Something went wrong.";
					header('location: ../../register.php');
				}
			}else
			{
				$_SESSION['message'] = "Emails do not match.";
				header('location: ../../register.php');
			}
		}else
		{
			$_SESSION['message'] = "Passwords do not match.";
			header('location: ../../register.php');
		}
	}
}

//Login user
if(isset($_POST['login_btn']))
{
	$loginEmail = mysqli_real_escape_string($con,$_POST['email']);
	$loginPassword = mysqli_real_escape_string($con,$_POST['password']);

	$login_query = "SELECT * FROM users WHERE email='$loginEmail' AND password='$loginPassword'";
	$login_query_run = mysqli_query($con, $login_query);

	if(!mysqli_num_rows($login_query_run) > 0)
	{
		$_SESSION['message'] = "Invalid credentials.";
		header('location: ../../login.php');

	}else
	{
		$_SESSION['auth'] = true;

		$userdata = mysqli_fetch_array($login_query_run);
		$userUsername = $userdata['username'];
		$userEmail = $userdata['email'];

		$_SESSION['auth_user'] = ['username' => $userUsername, 'email' => $userEmail];

		$_SESSION['message'] = "Logged in successfully.";
		header('location: ../../index.php');

	}
}

?>