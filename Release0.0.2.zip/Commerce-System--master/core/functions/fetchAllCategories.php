<?php
include 'config/dbcon.php';

//Predefine sql statement
$sql="select * from categories";

//Display dynamic records
foreach ($dbo->query($sql) as $row) {
	if ($row['category_image'] == "image") { $image = "https://via.placeholder.com/240x240x.jpg"; }else{ $image = $row['category_image']; }
		echo '<!-- '. $row['category_slug'] .' Start -->';
		echo '<div class="w-full md:w-1/3 xl:w-1/4 p-6">';
		echo '<a href="categories.php?q='. $row['category_slug'] .'"><img src="'. $image .'" class="w-full rounded-xl hover:shadow-lg"></a>';
		echo '';
		echo '<div class="pt-3 flex items-center justify-between">';
		echo '<a href="categories.php?q='. $row['category_slug'] .'">'. $row['category_name'] .'</a>';
		echo '';
		echo '</div>';
		echo '</div>';
		echo '<!-- '. $row['category_slug'] .' End -->';
}
?>
