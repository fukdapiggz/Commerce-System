<?php
include 'config/dbcon.php';
$sql = "SELECT * FROM products WHERE product_sku='$productSku'";
if($result = mysqli_query($con, $sql)){
    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_array($result)){
            if ($row['product_image'] == "image") { $image = "https://via.placeholder.com/240x240x.jpg"; }else{ $image = $row['product_image']; }
        	echo '<!-- '. $row['product_name'] .' Start -->';
        	echo '<div class="images w-full mb-6 lg:mb-0 lg:w-3/5">';
        	echo '<img class="rounded-xl" src="'. $image .'">';
        	echo '</div>';
        	echo '';
        	echo '<div class="information w-full lg:w-2/5 lg:p-6">';
        	echo '<h1 class="text-2xl">'. $row['product_name'] .'</h1>';
            echo '<p class="mt-1 text-gray-400">$'. $row['product_price'] .'0 NZD</p>';
            echo '<p class="mt-6 text-gray-700">'. $row['product_desc'] .'</p>';
            echo '<a class="add-to-cart text-'. $confPrimaryColour .'-500 hover:text-'. $confPrimaryColour .'-800" data-name="'. $row['product_name'] .'" data-price="'. $row['product_price'] .'">'. $svgCart .' Add to Cart</a>';
        	echo '</div>';
            echo '<!-- '. $row['product_name'] .' End -->';
        }
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "Error finding product.<br />Are you the site owner?<br />Check if you have Products in your Admin Panel!";
    }
} else{
    echo "ERROR: Could not execute $sql. ". mysqli_error($con);
}
 
// Close connection
mysqli_close($con);
?>