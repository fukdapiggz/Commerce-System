<?php require('assets/includes/global/fetchCurrentConfig.php'); ?>

<!doctype html>
<?php require 'assets/includes/global/urls.php'; ?>

<html lang="en">
  <head>
    <?php 
    $globalTitle = 'Admin Index'; 
    $globalKeywords = 'hi; frontpage; home';
    $globalDescription = '';
    include 'assets/includes/global/headers.php';
    ?>
  </head>

  <body>

      <!-- Sidebar Start --><?php include 'assets/includes/sidebar.php'; ?><!-- Sidebar Start -->

      <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">

        <!-- Main Navbar Start --><?php include 'assets/includes/nav.php'; ?><!-- Main Navbar End -->

        <div class="max-w-6xl mx-auto flex flex-wrap items-start py-6 px-6 xl:px-0">
        <!-- Content Start: <?= $globalTitle; ?> -->

          Dashboard Config

<div class="flex flex-wrap -mx-3 mb-6">
  <div class="w-full px-3">
    <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="blah">Facebook</label>
    <input class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" id="blah" name="blah" type="text" placeholder="<?php if (isset($Facebook)) {echo $Facebook;}else{echo "Facebook";} ?>" value="<?php if ($Facebook != "") {echo $Facebook;} ?>">
  </div>
</div>




          

        <!-- Content End: <?= $globalTitle; ?> -->
        </div>

        <?php include 'assets/includes/footer.php'; ?>
      
      </main>

    <!-- Scripts Start --><?php include 'assets/includes/global/scripts.php'; ?><!-- Scripts End -->

  </body>
</html>