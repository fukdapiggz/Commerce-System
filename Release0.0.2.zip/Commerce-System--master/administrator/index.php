<?php require('assets/includes/global/fetchCurrentConfig.php'); ?>

<!doctype html>
<?php require 'assets/includes/global/urls.php'; ?>

<html lang="en">
  <head>
    <?php 
    $globalTitle = 'Admin Index'; 
    $globalKeywords = 'hi; frontpage; home';
    $globalDescription = '';
    include 'assets/includes/global/headers.php';
    ?>
  </head>

  <body>

      <!-- Sidebar Start --><?php include 'assets/includes/sidebar.php'; ?><!-- Sidebar Start -->

      <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">

        <!-- Main Navbar Start --><?php include 'assets/includes/nav.php'; ?><!-- Main Navbar End -->

        <div class="max-w-6xl mx-auto flex flex-wrap items-start py-6 px-6 xl:px-0">
        <!-- Content Start: <?= $globalTitle; ?> -->

          Dashboard Config

          <h3 class = "text-primary">Products Pagination</h3>
			<hr style = "border-top:1px dotted #000;"/>
			<div class = "table-responsive" id = "load_data">	
				
			</div>	

      <script src = "assets/js/allProducts.ajax.js"></script>


          

        <!-- Content End: <?= $globalTitle; ?> -->
        </div>

        <?php include 'assets/includes/footer.php'; ?>
      
      </main>

    <!-- Scripts Start --><?php include 'assets/includes/global/scripts.php'; ?><!-- Scripts End -->

  </body>
</html>