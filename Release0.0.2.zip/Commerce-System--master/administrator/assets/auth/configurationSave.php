<?php
include('../../../config/dbcon.php');

include('../includes/plugins/ColorNameToHex.php');
include('../includes/plugins/ColorFound.php');

$get_currentform_data = "SELECT * FROM conf";
$get_currentform_data_run = mysqli_query($con, $get_currentform_data);

$currentFormData = mysqli_fetch_array($get_currentform_data_run);
$currentFacebook = $currentFormData['facebookLink'];
$currentInstagram = $currentFormData['instagramLink'];
$currentTwitter = $currentFormData['twitterLink'];
$currentServerPrimary = $currentFormData['primaryColour']; //colourname
$currentBouncy = $currentFormData['bouncyNav'];

//Change $currentPrimary to a hex value to display form using function.php
$currentPrimary = color_name_to_hex($currentServerPrimary);

if (isset($_POST['links_save_btn'])) {
	//Get data from config form
	$facebookLink = $_POST['facebookLink'];
	$instagramLink = $_POST['instagramLink'];
	$twitterLink = $_POST['twitterLink'];
	$formPrimaryColour = $_POST['primaryColour']; //hex
	$bouncyNav = $_POST['bouncyNav'];

	//Turn Hex into color name using ColorFound.php plugin
	$colorFound = new ColorFound;
	$primaryColour = $colorFound->getName($formPrimaryColour); 

	//Update fields on server, if forms have changed
	if ($currentFacebookSet = 1) {
		if ($currentFacebook != $facebookLink ) {
			$update_facebook_query = "UPDATE conf SET facebookLink=$facebookLink WHERE facebookLink=$currentFacebook";
			$update_facebook_query_run = mysqli_query($con, $update_facebook_query);
			header("location: ../../index.php");

			if ($currentInstagramSet = 1) {
				if ($currentInstagram != $instagramLink ) {
					$update_instagram_query = "UPDATE conf SET instagramLink=$instagramLink WHERE instagramLink=$currentInstagram";
					$update_instagram_query_run = mysqli_query($con, $update_instagram_query);
					header("location: ../../index.php");

					if ($currentTwitterSet = 1) {
						if ($currentTwitter != $twitterLink ) {
							$update_twitter_query = "UPDATE conf SET twitterLink=$twitterLink WHERE twitterLink=$currentTwitter";
							$update_twitter_query_run = mysqli_query($con, $update_twitter_query);
							header("location: ../../index.php");

							if ($currentPrimarySet = 1) {//input colourname
								if ($currentPrimary != $primaryColour ) {
									$update_primary_query = "UPDATE conf SET primaryColour=$primaryColour WHERE primaryColour=$primaryColour";
									$update_primary_query_run = mysqli_query($con, $update_primary_query);
									header("location: ../../index.php");

									if ($currentBouncySet = 1) {
										if ($currentBouncy != $bouncyNav ) {
											$update_bouncy_query = "UPDATE conf SET bouncyNav=$bouncyNav WHERE bouncyNav=$bouncyNav";
											$update_bouncy_query_run = mysqli_query($con, $update_bouncy_query);
											header("location: ../../index.php");
										}
									}

								}
							}

						}
					}

				}
			}

		}
	}

	//If whole form has changed than enter these inputs and delete last
	$clear_current_query = "DELETE FROM conf WHERE id=1";
	$clear_current_query_run = mysqli_query($con, $clear_current_query);

	$insert_query = "INSERT INTO conf (id,facebookLink,instagramLink,twitterLink,primaryColour,bouncyNav) VALUES (1,'$facebookLink','$instagramLink','$twitterLink','$primaryColour','$bouncyNav')";
	$insert_query_run = mysqli_query($con, $insert_query);
	header("location: ../../index.php");
}
?>