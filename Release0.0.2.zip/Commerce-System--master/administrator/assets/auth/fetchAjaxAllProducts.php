<?php
	include('../../../config/dbcon.php');
	
	$record_per_page = 2;
	
	$page = "";
	$result = "";
	
	if(ISSET($_POST['page'])){
		$page = $_POST['page'];
	}else{
		$page =  1;
	}
	
	$start = ($page - 1) * $record_per_page;
	
	$query_book = $con->query ("SELECT * FROM `products` LIMIT $start, $record_per_page") or die(mysqli_error());
	
	$result .="
		<table class = 'table table-bordered'>
			<thead>
				<tr>
					<th colspan = '2'><center>List of Items/Products</center></th>
				</tr>
				<tr>
					<th>Item ID</th>
					<th>Item Cat</th>
					<th>Item SKU</th>
					<th>Item Name</th>
					<th>Item Price</th>
					<th>Item Desc</th>
					<th>Item Size</th>
					<th>Item Colour</th>
					<th>Item Image</th>
				</tr>
			</thead>
			<tbody>
	";
	
	while($i_book = $query_book->fetch_array()){
		$result .= "
			<tr>
				<td style = 'width:11%;'>".$i_book['id']."</td>
				<td style = 'width:11%;'>".$i_book['parent_category']."</td>
				<td style = 'width:11%;'>".$i_book['product_sku']."</td>
				<td style = 'width:11%;'>".$i_book['product_name']."</td>
				<td style = 'width:11%;'>".$i_book['product_price']."</td>
				<td style = 'width:11%;'>".$i_book['product_desc']."</td>
				<td style = 'width:11%;'>".$i_book['product_size']."</td>
				<td style = 'width:11%;'>".$i_book['product_colour']."</td>
				<td style = 'width:11%;'>".$i_book['product_image']."</td>
			</tr>
		";
	}
	$result .= "
		</tbody></table>
	";
	
	$q_page = $con->query("SELECT * FROM `products`") or die(mysqli_error());
	$v_page = $q_page->num_rows;
	$total_pages = ceil($v_page/$record_per_page);
	for($i = 1; $i <= $total_pages; $i++){
		$result .="<span class = 'pagination' style = 'cursor:pointer; margin:1px; padding:8px; border:1px solid #ccc;' id = '".$i."'>".$i."</span>";
	}
	$result .="
		<span class = 'pull-right'>Page of ".$page." out of ".$total_pages."</span>
	";
	echo $result;
?>