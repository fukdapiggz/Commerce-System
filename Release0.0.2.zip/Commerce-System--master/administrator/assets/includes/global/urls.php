<?php
//Admin URLs
$urlDashboard = 'index.php';
$urlLinks = 'links.php';
$urlTest = 'test.php';

$curURL = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);  
switch ($curURL) {
  case $urlDashboard:
    echo 'Dashboard';
    break;
  case $urlLinks:
    echo 'Links';
    break;  
  case $urlTest:
    echo 'Test';
    break;      
  default:
    echo 'Error in getting location.';
}
?>