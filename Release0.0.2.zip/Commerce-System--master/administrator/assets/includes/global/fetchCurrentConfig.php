<?php
include('../config/dbcon.php');

$get_configuration_data = "SELECT * FROM conf";
$get_configuration_data_run = mysqli_query($con, $get_configuration_data);

$configurationData = mysqli_fetch_array($get_configuration_data_run);
$Facebook = $configurationData['facebookLink'];
$Instagram = $configurationData['instagramLink'];
$Twitter = $configurationData['twitterLink'];
$PrimaryColour = $configurationData['primaryColour']; //colourname
if ($configurationData['bouncyNav'] == 'on') { $BouncyNav = "on"; }else{ $BouncyNav = ""; }
return
?>