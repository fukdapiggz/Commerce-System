<!doctype html>
<?php require 'core/includes/globalURLS.php'; ?>

<html lang="en">
  <head>
    <?php 
    $globalTitle = 'Products'; 
    $globalKeywords = 'all; information; products';
    $globalDescription = '';
    include 'core/includes/globalHeaders.php';
    ?>
  </head>

  <body>
    <div class="flex flex-col h-screen">

      <header class="py-5 bg-gray-700 text-white text-center"><?php //include sticky nav, basic ?></header>

      <main class="flex-1 overflow-y-auto p-5">

        <!-- Main Navbar Start --><?php include 'core/includes/globalNav.php'; ?><!-- Main Navbar End -->

        <?php if (isset($_GET['q'])) { $querySet = 1; }else{ $querySet = 0; } ?>
        <p class="p-8"><?php if ($querySet == 1) { echo '<a href="'. $urlProducts .'">'. $globalTitle ."</a> > " . $_GET['q']; }else{ echo $globalTitle; } ?></p>
        <div class="max-w-6xl mx-auto flex flex-wrap items-start py-6 px-6 xl:px-0">
        <!-- Content Start: <?= $globalTitle; ?> -->

          <div class="max-w-6xl mx-auto flex flex-wrap py-6 px-6 xl:px-0">

            <?php 
              if ($querySet == 0) { include 'core/functions/fetchAllProducts.php'; }else{
                $productSku = $_GET['q'];
                include 'core/functions/fetchPartialProduct.php';
              }
              ?>

          </div>

        <!-- Content End: <?= $globalTitle; ?> -->
        </div>

      </main>

      <footer><?php include 'core/includes/globalFooter.php'; ?></footer>
      
    </div>

    <!-- Scripts Start --><?php include 'core/includes/globalScripts.php'; ?><!-- Scripts End -->

  </body>
</html>